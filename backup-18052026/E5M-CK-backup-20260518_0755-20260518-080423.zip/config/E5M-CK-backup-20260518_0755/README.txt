═══════════════════════════════════════════════════════
E5M-CK Klipper backup - 2026-05-18
═══════════════════════════════════════════════════════

CONTENU :

klippy_extras/
  9 modules Python custom (ignorés par git Klipper)

klipper_internals/
  - configfile.py.MODIFIED : version avec filtres custom
  - c_helper.so : binaire C compilé Ingenic T31X MIPS
  - git_info_exclude.txt : règles git locales
  - gitignore.txt : règles git officielles
  - E5M-CK-commit.patch : commit custom format git patch

printer_configs/
  Tous les .cfg du dossier printer_data/config

moonraker_database/
  - moonraker-sql.db : historique prints, préférences API

guppyscreen/
  - guppyconfig.json (+ backups) : config UI de l'écran
  - themes/ : thèmes custom GuppyScreen
  - k1_mods/, scripts/ : mods et scripts custom
  - config/ : config Klipper pour l'écran (GuppyScreen/)
  - .e5m_ck_installed, .e5m_ck_version : marqueurs install

historical_baks/
  - .moonraker.conf.bkp
  - gcode_macro.cfg.bak.before_m204_clamp
  - printer.cfg.bak.before_fade_5
  - 20260511-071900.zip (backup système ancien)

═══════════════════════════════════════════════════════
FLUIDD BROWSER SETTINGS - À FAIRE MANUELLEMENT
═══════════════════════════════════════════════════════
Le thème Fluidd, la disposition du dashboard, les macros 
épinglées, les vues custom etc. sont stockés CÔTÉ NAVIGATEUR 
(localStorage), pas sur la Nebula.

Pour les exporter :
1. Ouvrir Fluidd dans le navigateur
2. Cliquer sur ⚙️ (icône engrenage en haut à droite)
3. Settings > Configuration (ou tout en bas)
4. Bouton "Export" / "Backup"
5. Télécharger le fichier .json
6. Le mettre dans ce dossier pour archive complète

A faire depuis CHAQUE navigateur où Fluidd est utilisé
(PC, téléphone, tablette).

═══════════════════════════════════════════════════════
POUR RESTAURER (en cas de réinstall complète) :
═══════════════════════════════════════════════════════
1. Modules Klipper : copier klippy_extras/* vers /usr/data/klipper/klippy/extras/
2. Binaire C : klipper_internals/c_helper.so vers /usr/data/klipper/klippy/chelper/
3. configfile.py modifié : klipper_internals/configfile.py.MODIFIED → /usr/data/klipper/klippy/configfile.py
4. Git exclude : klipper_internals/git_info_exclude.txt → /usr/data/klipper/.git/info/exclude
5. Configs Klipper : printer_configs/*.cfg → /usr/data/printer_data/config/
6. Database Moonraker : moonraker_database/moonraker-sql.db → /usr/data/printer_data/database/
7. GuppyScreen : guppyscreen/guppyconfig.json → /usr/data/guppyscreen/
   + guppyscreen/themes/, k1_mods/, scripts/ → /usr/data/guppyscreen/
   + guppyscreen/config/* → /usr/data/printer_data/config/GuppyScreen/
8. Commit custom (optionnel) : 
   cd /usr/data/klipper && git am < klipper_internals/E5M-CK-commit.patch
9. Restart : /etc/init.d/S55klipper_service restart

10. Importer le JSON Fluidd via l'UI (étape navigateur).
