═══════════════════════════════════════════════════════
E5M-CK Klipper backup - $(date)
═══════════════════════════════════════════════════════

CONTENU :

klippy_extras/
  9 modules Python custom (non trackés par git Klipper) :
  - accel_chip_proxy.py
  - adxl345_creality.py
  - calibrate_shaper_config.py
  - error_mcu.py
  - gcode_shell_command.py
  - guppy_config_helper.py
  - guppy_module_loader.py
  - probe_eddy_auto_calibrate.py
  - tmcstatus.py

klipper_internals/
  - configfile.py.MODIFIED : version modifiée avec filtres custom
  - c_helper.so : binaire C compilé pour Ingenic T31X MIPS
  - git_info_exclude.txt : règles git locales (.git/info/exclude)
  - gitignore.txt : règles git officielles
  - E5M-CK-commit.patch : commit custom format git patch

printer_configs/
  Tous les .cfg du dossier printer_data/config

POUR RESTAURER :
1. Remettre les 9 .py dans /usr/data/klipper/klippy/extras/
2. Remettre c_helper.so dans /usr/data/klipper/klippy/chelper/
3. Remettre exclude rules dans /usr/data/klipper/.git/info/exclude
4. Pour le commit : git am < E5M-CK-commit.patch (depuis /usr/data/klipper)
5. Restart : /etc/init.d/S55klipper_service restart
